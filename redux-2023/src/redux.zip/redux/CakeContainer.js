import React, {useState} from 'react'
import {connect,useDispatch,useSelector} from 'react-redux'
import {buyCake} from './cake/cakeAction'
// import {buyCake} from '../redux'


function CakeContainer() {
  const [number,setNumber]=useState(1)
  const numOfCakes=useSelector(state => state.cake.numofCakes)

  const dispatch=useDispatch()

  return (
    <div>
      <h1>Number of cakes - {numOfCakes}</h1>
      <input type="text" value={number} onChange={e=>setNumber(e.target.value)}></input>
      <button onClick={()=>dispatch(buyCake(number))}>Buy {number} Cake</button>
    </div>
  )
}

export default CakeContainer
